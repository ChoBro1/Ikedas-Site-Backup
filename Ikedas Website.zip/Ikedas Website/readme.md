Click index.html to access the local copy. 
The original website is www.ikedas.com. 
I made the local copy consist of all subpages that had 'www.ikedas.com'-- if any links led to other domains, they were not included in the local copy(they should pop up in the browser). 

In this attempt to create a locally browsable copy of the website www.ikedas.com, I noticed a couple things: 
- Some images do not load(either a failure to load, or unable to trace the source of the image)
- Some sub-pages take longer to load than expected. 

